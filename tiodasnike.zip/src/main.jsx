import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import TiodasNike from "./pages/TiodasNike";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <TiodasNike />
  </React.StrictMode>
);