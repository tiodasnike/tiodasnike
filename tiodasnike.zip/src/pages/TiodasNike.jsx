import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Instagram, ShoppingCart, User, Youtube, Phone, Tiktok } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../../firebase";

export default function TiodasNike() {
  const [cartItems, setCartItems] = useState(0);
  const [produtos, setProdutos] = useState([]);

  const handleAddToCart = () => {
    setCartItems(cartItems + 1);
  };

  useEffect(() => {
    const fetchData = async () => {
      const querySnapshot = await getDocs(collection(db, "produtos"));
      const items = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setProdutos(items);
    };
    fetchData();
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="bg-gray-900 text-center py-4 text-lg font-semibold border-b border-gray-800"
      >
        FRETE GRÁTIS para todo o Brasil em compras acima de R$199!
      </motion.div>

      <header className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
        <div className="text-2xl font-bold">TiodasNike</div>
        <div className="flex-1 mx-6 max-w-xl">
          <Input placeholder="Buscar produtos..." className="bg-gray-900 text-white" />
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="text-white">
            <User />
          </Button>
          <Button variant="ghost" size="icon" className="relative text-white">
            <ShoppingCart />
            {cartItems > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-xs rounded-full px-1">
                {cartItems}
              </span>
            )}
          </Button>
        </div>
      </header>

      <nav className="flex flex-wrap justify-center gap-6 py-4 border-b border-gray-800 text-sm uppercase">
        <a href="#" className="hover:underline">Jaquetas / Moletons</a>
        <a href="#" className="hover:underline">Calças / Shorts</a>
        <a href="#" className="hover:underline">Boné</a>
        <a href="#" className="hover:underline">Tênis</a>
        <a href="#" className="hover:underline">Acessórios</a>
      </nav>

      <section className="px-6 py-4 flex flex-wrap gap-4 border-b border-gray-800 text-sm">
        <select className="bg-gray-900 text-white p-2 rounded">
          <option>Tamanho</option>
          <option>P</option>
          <option>M</option>
          <option>G</option>
          <option>GG</option>
        </select>
        <select className="bg-gray-900 text-white p-2 rounded">
          <option>Cor</option>
          <option>Preto</option>
          <option>Branco</option>
          <option>Vermelho</option>
        </select>
        <select className="bg-gray-900 text-white p-2 rounded">
          <option>Preço</option>
          <option>Menor preço</option>
          <option>Maior preço</option>
        </select>
      </section>

      <main className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {produtos.map((produto, index) => (
          <motion.div
            key={produto.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-gray-900">
              <CardContent className="p-4">
                <div className="h-48 bg-gray-700 rounded mb-4 flex items-center justify-center">
                  <img src={produto.imagem} alt={produto.nome} className="h-full object-cover rounded" />
                </div>
                <h3 className="text-lg font-semibold">{produto.nome}</h3>
                <p className="text-sm text-gray-400">{produto.descricao}</p>
                <p className="text-sm text-white font-bold">R$ {produto.preco}</p>
                <Button
                  onClick={handleAddToCart}
                  className="mt-4 w-full bg-white text-black hover:bg-gray-200"
                >
                  Comprar
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </main>

      <footer className="px-6 py-6 border-t border-gray-800">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm mb-4 md:mb-0">© 2025 TiodasNike. Todos os direitos reservados.</p>
          <div className="flex items-center gap-4">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
              <Instagram className="w-6 h-6 hover:text-pink-500" />
            </a>
            <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer">
              <Tiktok className="w-6 h-6 hover:text-white" />
            </a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
              <Youtube className="w-6 h-6 hover:text-red-500" />
            </a>
            <a href="https://wa.me/5599999999999" target="_blank" rel="noopener noreferrer">
              <Phone className="w-6 h-6 hover:text-green-500" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}